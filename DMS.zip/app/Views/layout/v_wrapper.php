<?= $this->include('layout/v_head'); ?>
<?= $this->include('layout/v_nav'); ?>


<?= $this->renderSection('home') ?>
<?= $this->include('layout/v_footer'); ?>