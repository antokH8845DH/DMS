<?= $this->include('layout/v_head'); ?>


<?= $this->renderSection('container') ?>
<?= $this->include('layout/v_footer'); ?>