<?php

namespace App\Entities;

use CodeIgniter\Entity;

class Upload extends Entity
{
}
