<?php

namespace App\Entities;

use CodeIgniter\Entity;

class Listrik extends Entity
{
}
