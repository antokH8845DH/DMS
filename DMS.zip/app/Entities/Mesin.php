<?php

namespace App\Entities;

use CodeIgniter\Entity;

class Mesin extends Entity
{
}
