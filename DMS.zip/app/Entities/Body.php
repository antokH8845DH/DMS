<?php

namespace App\Entities;

use CodeIgniter\Entity;

class Body extends Entity
{
}
