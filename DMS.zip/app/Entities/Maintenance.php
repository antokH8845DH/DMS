<?php

namespace App\Entities;

use CodeIgniter\Entity;

class Maintenance extends Entity
{
}
